package com.mprojar.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int green = Color.rgb(7, 94, 66);
    private final int light = Color.rgb(239, 248, 243);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(green);
        getWindow().setNavigationBarColor(green);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(light);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(24));
        scroll.addView(page);

        TextView title = new TextView(this);
        title.setText("MP Rojgar");
        title.setTextSize(30);
        title.setTextColor(Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(dp(10), dp(25), dp(10), dp(5));
        title.setBackgroundColor(green);
        page.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("मध्य प्रदेश की नौकरी, एडमिट कार्ड, रिजल्ट और सरकारी योजनाएँ");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.WHITE);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(dp(16), 0, dp(16), dp(22));
        subtitle.setBackgroundColor(green);
        page.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        addSection(page, "सरकारी नौकरी और भर्ती", "नई भर्तियाँ, आवेदन और नोटिफिकेशन");
        addButton(page, "MPESB / व्यापम भर्ती", "https://esb.mp.gov.in/");
        addButton(page, "MPPSC भर्ती", "https://mppsc.mp.gov.in/");
        addButton(page, "देवास — बैंक नोट प्रेस भर्ती", "https://bnpdewas.spmcil.com/");
        addButton(page, "मध्य प्रदेश सरकारी पोर्टल", "https://mp.gov.in/");

        addSection(page, "एडमिट कार्ड और रिजल्ट", "आधिकारिक वेबसाइट पर उपलब्ध जानकारी देखें");
        addButton(page, "MPESB एडमिट कार्ड / रिजल्ट", "https://esb.mp.gov.in/");
        addButton(page, "MPPSC एडमिट कार्ड / रिजल्ट", "https://mppsc.mp.gov.in/");

        addSection(page, "सरकारी योजनाएँ", "योजना की पात्रता और आवेदन की जानकारी");
        addButton(page, "मध्य प्रदेश सरकार की योजनाएँ", "https://mp.gov.in/");

        TextView note = new TextView(this);
        note.setText("ध्यान दें: यह ऐप आधिकारिक वेबसाइटों के लिंक खोलता है। नई जानकारी संबंधित विभाग की वेबसाइट पर निर्भर करती है। यह सरकारी ऐप नहीं है। किसी भी आवेदन से पहले आधिकारिक नोटिफिकेशन और तारीखें जाँचें।");
        note.setTextSize(13);
        note.setTextColor(Color.rgb(65, 75, 70));
        note.setPadding(dp(12), dp(18), dp(12), dp(10));
        page.addView(note);
        setContentView(scroll);
    }

    private void addSection(LinearLayout page, String heading, String detail) {
        TextView h = new TextView(this);
        h.setText(heading); h.setTextSize(19); h.setTypeface(null, Typeface.BOLD);
        h.setTextColor(green); h.setPadding(dp(4), dp(22), dp(4), dp(4)); page.addView(h);
        TextView d = new TextView(this);
        d.setText(detail); d.setTextSize(13); d.setTextColor(Color.DKGRAY);
        d.setPadding(dp(4), 0, dp(4), dp(8)); page.addView(d);
    }

    private void addButton(LinearLayout page, String label, String url) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(5), 0, dp(5)); page.addView(b, lp);
        b.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
            catch (Exception e) { Toast.makeText(this, "वेबसाइट नहीं खुल सकी। इंटरनेट जाँचें।", Toast.LENGTH_LONG).show(); }
        });
    }
    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
