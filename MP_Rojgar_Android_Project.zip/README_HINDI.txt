MP Rojgar Android Project (Starter)

यह Android Studio project है, APK नहीं।
फीचर:
- MPESB, MPPSC, BNP Dewas और MP Government के आधिकारिक लिंक
- नौकरी, एडमिट कार्ड, रिजल्ट और योजनाओं के सेक्शन
- मोबाइल-फ्रेंडली सरल हिंदी UI

महत्वपूर्ण:
- यह starter app अभी केवल आधिकारिक वेबसाइट लिंक खोलता है।
- यह अपने-आप नई नौकरी की सूची/नोटिफिकेशन डाउनलोड नहीं करता। वास्तविक automatic updates के लिए डेटा/API/RSS या backend integration अलग से बनानी होगी।
- APK बनाने के लिए Android Studio और Android SDK के साथ project build करना होगा।
- ऐप सरकारी ऐप नहीं है; आवेदन से पहले आधिकारिक नोटिफिकेशन जाँचें।
